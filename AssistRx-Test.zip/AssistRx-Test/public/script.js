

/**
 * Project: assistrx programming test
 * this script helps with the patient page
 * 
 */


window.console = window.console || {log : function(){return false;}};

;(function($, window, document, undefined) {

    

})(jQuery, window, document);